/* subroutine record for calculating the upstream/downstream CAM motion */
/*																		*/
/*																		*/
/* Version History:														*/
/*	04/03/2008	ses		initial version									*/
/*																		*/

#include <epicsStdlib.h>
#include <epicsStdioRedirect.h>
#include <epicsMath.h>
#include <dbAccess.h>
#include <dbEvent.h>
#include <dbDefs.h>
#include <recGbl.h>
#include <dbCommon.h>
#include <registryFunction.h>
#include <epicsExport.h>
#include <recSup.h>
#include <genSubRecord.h>
#include <pinfo.h>
#include <alarm.h>

/* r      = radius of CAMs												*/
/* s23    = distance between CAM2 and CAM3 centers						*/
/* s45    = distance between CAM4 and CAM5 centers						*/
/* v1     = height from CAM 1/2/3 center to beam center					*/
/* v45    = height from CAM 1/2/3 center to beam center					*/
/* h1     = distance between beam center and CAM1						*/
/* h23    = distance between beam center and CAM2/3 mid point			*/
/* beta1  = angle of CAM1 wedge block in radians						*/
/* beta2  = angle of CAM2 wedge block in radians						*/
/* beta3  = angle of CAM3 wedge block in radians						*/
/* beta4  = angle of CAM4 wedge block in radians						*/
/* beta5  = angle of CAM5 wedge block in radians						*/
/* Xus    = setpoint for X on the Upstream CAMs							*/
/* Yus    = setpoint for Y on the Upstream CAMs							*/
/* Xds    = setpoint for X on the Downstream CAMs						*/
/* Yds    = setpoint for Y on the Downstream CAMs						*/
/* gammaRoll  = amount of roll in the system 							*/
/* l      = amount of excentricity of the CAMs 							*/

/* VALA   = phi1 = calculated new position for moving CAM1				*/
/* VALB   = phi2 = calculated new position for moving CAM2				*/
/* VALC   = phi3 = calculated new position for moving CAM3				*/
/* VALD   = phi4 = calculated new position for moving CAM4				*/
/* VALE   = phi5 = calculated new position for moving CAM5				*/

/*
	r		= *(double *)pgsub->a;
	s23		= *(double *)pgsub->b;
	s45		= *(double *)pgsub->c;
	v1		= *(double *)pgsub->d;
	v45		= *(double *)pgsub->e;
	h1		= *(double *)pgsub->f;
	h23		= *(double *)pgsub->g;
	beta1	= *(double *)pgsub->h;
	beta2	= *(double *)pgsub->i;
	beta3	= *(double *)pgsub->j;
	beta4	= *(double *)pgsub->k;
	beta5	= *(double *)pgsub->l;
	Xus		= *(double *)pgsub->m;
	Yus		= *(double *)pgsub->n;
	Xds		= *(double *)pgsub->o;
	Yds		= *(double *)pgsub->p;
	gammaRoll	= *(double *)pgsub->q;
	l		= *(double *)pgsub->r;
*/

#define	CONV	57.29577951308232087721
#define PI		3.14159265358979323846
#define DEBUG	1

double	CAM1_angle(double beta1, double h1, double l, double r, double v1, double Xus, double Yus, double gammaRoll)
{
	double	a = tan(beta1);
	double	b = -v1 + r;
	double	a_ = tan(gammaRoll + beta1);
	double	b_ = Yus + b*cos(gammaRoll) + (b*sin(gammaRoll) - Xus)*a_;
	double	X0 = h1;
	double	Y0 = -v1;

	double	A = -a_;
	double	B = 1;
	double	C = (a_*X0 - Y0 + b_ - r/cos(atan(a_)))/l;

	if( (fabs(C/sqrt(pow(A,2)+pow(B,2))) > 1.0) && DEBUG)
		printf("\ncalcCM1\n\tValue of equation c/sqrt(a^2+b^2) is out of range!\n\tValue : %f\n", C/sqrt(pow(A,2)+pow(B,2)));

	double	phi = asin(C/sqrt(pow(A,2)+pow(B,2))) - atan(A/B);
	phi = phi * 180/PI;

	return phi;
}

double	CAM2_angle(double beta2, double h23, double l, double r, double s23, double v1, double Xus, double Yus, double gammaRoll)
{
	double	a = tan(beta2);
	double	b = -h23 - s23/2 - v1 + sqrt(2)*r;
	double	a_ = tan(gammaRoll + beta2);
	double	b_ = Yus + b*cos(gammaRoll) + (b*sin(gammaRoll) - Xus)*a_;
	double	X0 = -h23 - s23/2;
	double	Y0 = -v1;

	double	A = -a_;
	double	B = 1;
	double	C = (a_*X0 - Y0 + b_ - r/cos(atan(a_)))/l;
	
	if ( (fabs(C/sqrt(pow(A,2)+pow(B,2))) > 1.0) && DEBUG )
		printf("\ncalcCM2\n\tValue of equation c/sqrt(a^2+b^2) is out of range!\n\tValue : %f\n", C/sqrt(pow(A,2)+pow(B,2)));

	double	phi = asin(C/sqrt(pow(A,2)+pow(B,2))) - atan(A/B);
	phi = phi * 180/PI;

	return phi;
}

double	CAM3_angle(double beta3, double h23, double l, double r, double s23, double v1, double Xus, double Yus, double gammaRoll)
{
	double	a = tan(beta3);
	double	b = h23 - s23/2 - v1 + sqrt(2)*r;
	double	a_ = tan(gammaRoll + beta3);
	double	b_ = Yus + b*cos(gammaRoll) + (b*sin(gammaRoll) - Xus)*a_;
	double	X0 = -h23 + s23/2;
	double	Y0 = -v1;

	double	A = -a_;
	double	B = 1;
	double	C = (a_*X0 - Y0 + b_ - r/cos(atan(a_)))/l;
	
	if ( (fabs(C/sqrt(pow(A,2)+pow(B,2))) > 1.0) && DEBUG)
		printf("\ncalcCM3\n\tValue of equation c/sqrt(a^2+b^2) is out of range!\n\tValue : %f\n", C/sqrt(pow(A,2)+pow(B,2)));


	double	phi = asin(C/sqrt(pow(A,2)+pow(B,2))) - atan(A/B);
	phi = phi * 180/PI;

	return phi;
}

double	CAM4_angle(double beta4, double l, double r, double s45, double v45, double Xds, double Yds, double gammaRoll)
{
	double	a = tan(beta4);
	double	b = -s45/2 - v45 + sqrt(2)*r;
	double	a_ = tan(gammaRoll + beta4);
	double	b_ = Yds + b*cos(gammaRoll) + (b*sin(gammaRoll) - Xds)*a_;
	double	X0 = -s45/2;
	double	Y0 = -v45;

	double	A = -a_;
	double	B = 1;
	double	C = (a_*X0 - Y0 + b_ - r/cos(atan(a_)))/l;
	
	if ( (fabs(C/sqrt(pow(A,2)+pow(B,2))) > 1.0) && DEBUG )
		printf("\ncalcCM4\n\tValue of equation c/sqrt(a^2+b^2) is out of range!\n\tValue : %f\n", C/sqrt(pow(A,2)+pow(B,2)));

	double	phi = asin(C/sqrt(pow(A,2)+pow(B,2))) - atan(A/B);
	phi = phi * 180/PI;
	
	return phi;
}

double	CAM5_angle(double beta5, double l, double r, double s45, double v45, double Xds, double Yds, double gammaRoll)
{
	double	a = tan(beta5);
	double	b = -s45/2 - v45 + sqrt(2)*r;
	double	a_ = tan(gammaRoll + beta5);
	double	b_ = Yds + b*cos(gammaRoll) + (b*sin(gammaRoll) - Xds)*a_;
	double	X0 = s45/2;
	double	Y0 = -v45;

	double	A = -a_;
	double	B = 1;
	double	C = (a_*X0 - Y0 + b_ - r/cos(atan(a_)))/l;
	
	if ( (fabs(C/sqrt(pow(A,2)+pow(B,2))) > 1.0) && DEBUG )
		printf("\ncalcCM5:\n\tValue of equation c/sqrt(a^2+b^2) is out of range!\n\tValue : %f\n", C/sqrt(pow(A,2)+pow(B,2)));

	double	phi = asin(C/sqrt(pow(A,2)+pow(B,2))) - atan(A/B);	
	phi = phi * 180/PI;

	return phi;
}


long	calcCMxInit(struct genSubRecord *pgsub)
{
	return(0);
}

long	calcCM1(struct genSubRecord *pgsub)
{
	double	r		= *(double *)pgsub->a;
	double	s23		= *(double *)pgsub->b;
	double	s45		= *(double *)pgsub->c;
	double	v1		= *(double *)pgsub->d;
	double	v45		= *(double *)pgsub->e;
	double	h1		= *(double *)pgsub->f;
	double	h23		= *(double *)pgsub->g;
	double	beta1	= *(double *)pgsub->h;
	double	beta2	= *(double *)pgsub->i;
	double	beta3	= *(double *)pgsub->j;
	double	beta4	= *(double *)pgsub->k;
	double	beta5	= *(double *)pgsub->l;
	double	Xus		= *(double *)pgsub->m;
	double	Yus		= *(double *)pgsub->n;
	double	Xds		= *(double *)pgsub->o;
	double	Yds		= *(double *)pgsub->p;
	double	gammaRoll	= *(double *)pgsub->q;
	double	l		= *(double *)pgsub->r;

/*	if(DEBUG) {
		printf("\nr %f, v1 %f, h1 %f, beta1 %f, Xus %f, Yus %f, roll %f, l %f\n\n", r,v1,h1,beta1,Xus,Yus,gammaRoll,l);
	}	
*/
	double phi1 = CAM1_angle(beta1, h1, l, r, v1, Xus, Yus, gammaRoll);
	double phi2 = CAM2_angle(beta2, h23, l, r, s23, v1, Xus, Yus, gammaRoll);
	double phi3 = CAM3_angle(beta3, h23, l, r, s23, v1, Xus, Yus, gammaRoll);
	double phi4 = CAM4_angle(beta4, l, r, s45, v45, Xds, Yds, gammaRoll);
	double phi5 = CAM5_angle(beta5, l, r, s45, v45, Xds, Yds, gammaRoll);

	if (DEBUG)
		printf("\n\t\tPHI1 : %f\n",phi1);	

	if ( isnan(phi1) || isnan(phi2) || isnan(phi3) || isnan(phi4) || isnan(phi5) )
	{
		double	phi1_old = *(double *)pgsub->vala;
		if(DEBUG)
			printf("\n\t\tPHI1_OLD : %f\n",phi1_old);
//		*(double *)pgsub->vala = phi1_old;
		pgsub->brsv = MINOR_ALARM;
		
		return(-1);
	}
	else
		*(double *)pgsub->vala = phi1;
	
return(0);
}

long	calcCM2(struct genSubRecord *pgsub)
{
	double	r		= *(double *)pgsub->a;
	double	s23		= *(double *)pgsub->b;
	double	s45		= *(double *)pgsub->c;
	double	v1		= *(double *)pgsub->d;
	double	v45		= *(double *)pgsub->e;
	double	h1		= *(double *)pgsub->f;
	double	h23		= *(double *)pgsub->g;
	double	beta1	= *(double *)pgsub->h;
	double	beta2	= *(double *)pgsub->i;
	double	beta3	= *(double *)pgsub->j;
	double	beta4	= *(double *)pgsub->k;
	double	beta5	= *(double *)pgsub->l;
	double	Xus		= *(double *)pgsub->m;
	double	Yus		= *(double *)pgsub->n;
	double	Xds		= *(double *)pgsub->o;
	double	Yds		= *(double *)pgsub->p;
	double	gammaRoll	= *(double *)pgsub->q;
	double	l		= *(double *)pgsub->r;

/*	if(DEBUG) {
		printf("\nr %f, v1 %f, s23 %f, h23 %f, beta2 %f, Xus %f, Yus %f, roll %f, l %f\n\n", r,v1,s23,h23,beta2,Xus,Yus,gammaRoll,l);
	}	
*/
	double phi1 = CAM1_angle(beta1, h1, l, r, v1, Xus, Yus, gammaRoll);
	double phi2 = CAM2_angle(beta2, h23, l, r, s23, v1, Xus, Yus, gammaRoll);
	double phi3 = CAM3_angle(beta3, h23, l, r, s23, v1, Xus, Yus, gammaRoll);
	double phi4 = CAM4_angle(beta4, l, r, s45, v45, Xds, Yds, gammaRoll);
	double phi5 = CAM5_angle(beta5, l, r, s45, v45, Xds, Yds, gammaRoll);

	if(DEBUG)
		printf("\n\t\tPHI2 : %f\n",phi2);

	if ( isnan(phi1) || isnan(phi2) || isnan(phi3) || isnan(phi4) || isnan(phi5) )
	{
		double	phi2_old = *(double *)pgsub->valb;
		if(DEBUG)
			printf("\n\t\tPHI2_OLD : %f\n",phi2_old);
//		*(double *)pgsub->valb = phi2_old;
		pgsub->brsv = MINOR_ALARM;
		
		return(-1);
	}
	else
		*(double *)pgsub->valb = phi2;

return(0);
}

long	calcCM3(struct genSubRecord *pgsub)
{
	double	r		= *(double *)pgsub->a;
	double	s23		= *(double *)pgsub->b;
	double	s45		= *(double *)pgsub->c;
	double	v1		= *(double *)pgsub->d;
	double	v45		= *(double *)pgsub->e;
	double	h1		= *(double *)pgsub->f;
	double	h23		= *(double *)pgsub->g;
	double	beta1	= *(double *)pgsub->h;
	double	beta2	= *(double *)pgsub->i;
	double	beta3	= *(double *)pgsub->j;
	double	beta4	= *(double *)pgsub->k;
	double	beta5	= *(double *)pgsub->l;
	double	Xus		= *(double *)pgsub->m;
	double	Yus		= *(double *)pgsub->n;
	double	Xds		= *(double *)pgsub->o;
	double	Yds		= *(double *)pgsub->p;
	double	gammaRoll	= *(double *)pgsub->q;
	double	l		= *(double *)pgsub->r;

/*	if(DEBUG) {
		printf("\nr %f, v1 %f, s23 %f, h23 %f, beta3 %f, Xus %f, Yus %f, roll %f, l %f\n\n", r,v1,s23,h23,beta3,Xus,Yus,gammaRoll,l);
	}	
*/
	double phi1 = CAM1_angle(beta1, h1, l, r, v1, Xus, Yus, gammaRoll);
	double phi2 = CAM2_angle(beta2, h23, l, r, s23, v1, Xus, Yus, gammaRoll);
	double phi3 = CAM3_angle(beta3, h23, l, r, s23, v1, Xus, Yus, gammaRoll);
	double phi4 = CAM4_angle(beta4, l, r, s45, v45, Xds, Yds, gammaRoll);
	double phi5 = CAM5_angle(beta5, l, r, s45, v45, Xds, Yds, gammaRoll);

	if(DEBUG)
		printf("\n\t\tPHI3 : %f\n",phi3);	

	if ( isnan(phi1) || isnan(phi2) || isnan(phi3) || isnan(phi4) || isnan(phi5) )
	{
		double	phi3_old = *(double *)pgsub->valc;
		if(DEBUG)
			printf("\n\t\tPHI3_OLD : %f\n",phi3_old);
//		*(double *)pgsub->valc = phi3_old;
		pgsub->brsv = MINOR_ALARM;
		
		return(-1);
	}
	else
		*(double *)pgsub->valc = phi3;

return(0);
}

long	calcCM4(struct genSubRecord *pgsub)
{
	double	r		= *(double *)pgsub->a;
	double	s23		= *(double *)pgsub->b;
	double	s45		= *(double *)pgsub->c;
	double	v1		= *(double *)pgsub->d;
	double	v45		= *(double *)pgsub->e;
	double	h1		= *(double *)pgsub->f;
	double	h23		= *(double *)pgsub->g;
	double	beta1	= *(double *)pgsub->h;
	double	beta2	= *(double *)pgsub->i;
	double	beta3	= *(double *)pgsub->j;
	double	beta4	= *(double *)pgsub->k;
	double	beta5	= *(double *)pgsub->l;
	double	Xus		= *(double *)pgsub->m;
	double	Yus		= *(double *)pgsub->n;
	double	Xds		= *(double *)pgsub->o;
	double	Yds		= *(double *)pgsub->p;
	double	gammaRoll	= *(double *)pgsub->q;
	double	l		= *(double *)pgsub->r;

/*	if(DEBUG) {
		printf("\nr %f, v45 %f, s45 %f, beta4 %f, Xds %f, Yds %f,roll %f, l %f\n\n",r,v45,s45,beta4,Xds,Yds,gammaRoll,l);
	}	
*/
	double phi1 = CAM1_angle(beta1, h1, l, r, v1, Xus, Yus, gammaRoll);
	double phi2 = CAM2_angle(beta2, h23, l, r, s23, v1, Xus, Yus, gammaRoll);
	double phi3 = CAM3_angle(beta3, h23, l, r, s23, v1, Xus, Yus, gammaRoll);
	double phi4 = CAM4_angle(beta4, l, r, s45, v45, Xds, Yds, gammaRoll);
	double phi5 = CAM5_angle(beta5, l, r, s45, v45, Xds, Yds, gammaRoll);

	if(DEBUG)
		printf("\n\t\tPHI4 : %f\n",phi4);

	if ( isnan(phi1) || isnan(phi2) || isnan(phi3) || isnan(phi4) || isnan(phi5) )
	{
		double	phi4_old = *(double *)pgsub->vald;
		if(DEBUG)
			printf("\n\t\tPHI4_OLD : %f\n",phi4_old);
//		*(double *)pgsub->vald = phi4_old;
		pgsub->brsv = MINOR_ALARM;
		
		return(-1);
	}
	else
		*(double *)pgsub->vald = phi4;

return(0);
}

long	calcCM5(struct genSubRecord *pgsub)
{
	double	r		= *(double *)pgsub->a;
	double	s23		= *(double *)pgsub->b;
	double	s45		= *(double *)pgsub->c;
	double	v1		= *(double *)pgsub->d;
	double	v45		= *(double *)pgsub->e;
	double	h1		= *(double *)pgsub->f;
	double	h23		= *(double *)pgsub->g;
	double	beta1	= *(double *)pgsub->h;
	double	beta2	= *(double *)pgsub->i;
	double	beta3	= *(double *)pgsub->j;
	double	beta4	= *(double *)pgsub->k;
	double	beta5	= *(double *)pgsub->l;
	double	Xus		= *(double *)pgsub->m;
	double	Yus		= *(double *)pgsub->n;
	double	Xds		= *(double *)pgsub->o;
	double	Yds		= *(double *)pgsub->p;
	double	gammaRoll	= *(double *)pgsub->q;
	double	l		= *(double *)pgsub->r;

/*	if(DEBUG) {
		printf("\nr %f, v45 %f, s45 %f, beta5 %f, Xds %f, Yds %f,roll %f, l %f\n\n",r,v45,s45,beta5,Xds,Yds,gammaRoll,l);
	}	
*/
	double phi1 = CAM1_angle(beta1, h1, l, r, v1, Xus, Yus, gammaRoll);
	double phi2 = CAM2_angle(beta2, h23, l, r, s23, v1, Xus, Yus, gammaRoll);
	double phi3 = CAM3_angle(beta3, h23, l, r, s23, v1, Xus, Yus, gammaRoll);
	double phi4 = CAM4_angle(beta4, l, r, s45, v45, Xds, Yds, gammaRoll);
	double phi5 = CAM5_angle(beta5, l, r, s45, v45, Xds, Yds, gammaRoll);

	if(DEBUG)
		printf("\n\t\tPHI5 : %f\n",phi5);	

	if ( isnan(phi1) || isnan(phi2) || isnan(phi3) || isnan(phi4) || isnan(phi5) )
	{
		double	phi5_old = *(double *)pgsub->vale;
		if(DEBUG)
			printf("\n\t\tPHI5_OLD : %f\n",phi5_old);
//		*(double *)pgsub->vale = phi5_old;
		pgsub->brsv = MINOR_ALARM;
		
		return(-1);
	}
	else
		*(double *)pgsub->vale = phi5;

return(0);
}

epicsRegisterFunction(calcCMxInit);
epicsRegisterFunction(calcCM1);
epicsRegisterFunction(calcCM2);
epicsRegisterFunction(calcCM3);
epicsRegisterFunction(calcCM4);
epicsRegisterFunction(calcCM5);
