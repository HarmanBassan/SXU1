#include <epicsStdlib.h>
#include <epicsStdioRedirect.h>
#include <epicsMath.h>
#include <dbAccess.h>
#include <dbEvent.h>
#include <dbDefs.h>
#include <recGbl.h>
#include <dbCommon.h>
#include <registryFunction.h>
#include <epicsExport.h>
#include <recSup.h>
#include <aSubRecord.h>
#include <pinfo.h>

#define DEBUG 0
#define PI 3.141592653

double deg2rad(double d){
	return d * PI / 180.;
}

double alpha1y(double e1, double phi1){
	double f = fabs(e1)*sin(phi1);
	if (DEBUG)
	{
		printf("\nalpha1y: %f", f);
	}
	return f;
}
double alpha23x(double e2, double phi2, double e3, double phi3){
	double f = (1./sqrt(2))*(fabs(e2)*sin(phi2)-fabs(e3)*sin(phi3));
	if (DEBUG)
	{
		printf("\nalpha23x: %f", f);
	}
	return f;
}
double alpha23y(double e2, double phi2, double e3, double phi3){
	double f = 0.707*(fabs(e2)*sin(phi2)+fabs(e3)*sin(phi3));
	if (DEBUG)
	{
		printf("\nalpha23y: %f", f);
	}
	return f;
}
double alpha45x(double e4, double phi4, double e5, double phi5){
	double f = (1./sqrt(2))*(fabs(e4)*sin(phi4)-fabs(e5)*sin(phi5));
	if (DEBUG)
	{
		printf("\nalpha45x: %f", f);
	}
	return f;
}
double alpha45y(double e4, double phi4, double e5, double phi5){
	double f = (1./sqrt(2))*(fabs(e4)*sin(phi4)+fabs(e5)*sin(phi5));
	if (DEBUG)
	{
		printf("\nalpha45y: %f", f);
	}
	return f;
}
double Tusx(double e2, double phi2, double e3, double phi3, double th, double r23y){
	float f = alpha23x(e2,phi2,e3,phi3)+th/1000.*r23y;
	if (DEBUG)
	{
		printf("\nTusx: %f", f);
	}
	return f;
}
double Tusy(double e2, double phi2, double e3, double phi3, double th, double r23x){
	float f = alpha23y(e2,phi2,e3,phi3)-th/1000.*r23x;
	if (DEBUG)
	{
		printf("\nTusy: %f", f);
	}
	return f;
}
double Tdsx(double e4, double phi4, double e5, double phi5, double th, double r45y){
	float f = alpha45x(e4,phi4,e5,phi5)+th/1000.*r45y;
	if (DEBUG)
	{
		printf("\nTdsx: %f", f);
	}
	return f;
}
double Tdsy(double e4, double phi4, double e5, double phi5, double th, double r45x){
	float f = alpha45y(e4,phi4,e5,phi5)-th/1000.*r45x;
	if (DEBUG)
	{
		printf("\nTdsy: %f", f);
	}
	return f;
}
static int	calcInit(aSubRecord *pgsub)
{
	return(0);
}
static int calcThetaRead(aSubRecord *precord){
	double e1 = 	*(double*)precord->a;
	double phi1 = 	deg2rad(*(double*)precord->b);
	double e2 = 	*(double*)precord->c;
	double phi2 = 	deg2rad(*(double*)precord->d);
	double e3 = 	*(double*)precord->e;
	double phi3 = 	deg2rad(*(double*)precord->f);
	double zrel = 	*(double*)precord->g;
	double rp1x = 	*(double*)precord->h;
	double r23x = 	*(double*)precord->i;
	double r45x = 	*(double*)precord->j;
	double e4 = 	*(double*)precord->k;
	double phi4 = 	deg2rad(*(double*)precord->l);
	double e5 = 	*(double*)precord->m;
	double phi5 = 	deg2rad(*(double*)precord->n);

	double th = 1000.*(alpha1y(e1,phi1) - alpha23y(e2,phi2,e3,phi3)*zrel - alpha45y(e4,phi4,e5,phi5)*(1-zrel))/(rp1x - r23x*zrel - r45x*(1-zrel));
	if (DEBUG)
	{
		printf("\nThetaCalc: %f",th);
	}

	*(double *)precord->valc = th;

	return(0);
}

static int calcXRead(aSubRecord *precord){
	double zp4 = 	*(double*)precord->a;
	double zp2 = 	*(double*)precord->b;
	double e2 = 	*(double*)precord->c;
	double phi2 = 	deg2rad(*(double*)precord->d);
	double e3 = 	*(double*)precord->e;
	double phi3 = 	deg2rad(*(double*)precord->f);
	double theta = 	*(double*)precord->g;
	double r23y = 	*(double*)precord->h;
	double e4 = 	*(double*)precord->i;
	double phi4 = 	deg2rad(*(double*)precord->j);
	double e5 = 	*(double*)precord->k;
	double phi5 = 	deg2rad(*(double*)precord->l);
	double r45y = 	*(double*)precord->m;


	double x = (Tusx(e2,phi2,e3,phi3,theta,r23y)*zp4-Tdsx(e4,phi4,e5,phi5,theta,r45y)*zp2)/(zp4-zp2);
	if (DEBUG)
	{
		printf("\nXcalc: %f",x);
	}

	*(double *)precord->vala = x;

	return(0);
}
static int calcYRead(aSubRecord *precord){
	double zp4 = 	*(double*)precord->a;
	double zp2 = 	*(double*)precord->b;
	double e2 = 	*(double*)precord->c;
	double phi2 = 	deg2rad(*(double*)precord->d);
	double e3 = 	*(double*)precord->e;
	double phi3 = 	deg2rad(*(double*)precord->f);
	double theta = 	*(double*)precord->g;
	double r23x = 	*(double*)precord->h;
	double e4 = 	*(double*)precord->i;
	double phi4 = 	deg2rad(*(double*)precord->j);
	double e5 = 	*(double*)precord->k;
	double phi5 = 	deg2rad(*(double*)precord->l);
	double r45x = 	*(double*)precord->m;


	double y = (Tusy(e2,phi2,e3,phi3,theta,r23x)*zp4-Tdsy(e4,phi4,e5,phi5,theta,r45x)*zp2)/(zp4-zp2);
	if (DEBUG)
	{
		printf("\nYcalc: %f",y);
	}

	*(double *)precord->valb = y;

	return(0);
}
static int calcPsRead(aSubRecord *precord){
	double zp4 = 	*(double*)precord->a;
	double zp2 = 	*(double*)precord->b;
	double e4 = 	*(double*)precord->c;
	double phi4 = 	deg2rad(*(double*)precord->d);
	double e5 = 	*(double*)precord->e;
	double phi5 = 	deg2rad(*(double*)precord->f);
	double theta = 	*(double*)precord->g;
	double r45x = 	*(double*)precord->h;
	double e2 = 	*(double*)precord->i;
	double phi2 = 	deg2rad(*(double*)precord->j);
	double e3 = 	*(double*)precord->k;
	double phi3 = 	deg2rad(*(double*)precord->l);
	double r23x = 	*(double*)precord->m;


	double ps = 1000.*(Tdsy(e4,phi4,e5,phi5,theta,r45x) - Tusy(e2,phi2,e3,phi3,theta,r23x))/(zp4-zp2);
	if (DEBUG)
	{
		printf("\nPscalc: %f",ps);
	}

	*(double *)precord->vald = ps;

	return(0);
}
static int calcGaRead(aSubRecord *precord){
	double zp4 = 	*(double*)precord->a;
	double zp2 = 	*(double*)precord->b;
	double e4 = 	*(double*)precord->c;
	double phi4 = 	deg2rad(*(double*)precord->d);
	double e5 = 	*(double*)precord->e;
	double phi5 = 	deg2rad(*(double*)precord->f);
	double theta = 	*(double*)precord->g;
	double r45y = 	*(double*)precord->h;
	double e2 = 	*(double*)precord->i;
	double phi2 = 	deg2rad(*(double*)precord->j);
	double e3 = 	*(double*)precord->k;
	double phi3 = 	deg2rad(*(double*)precord->l);
	double r23y = 	*(double*)precord->m;


	double ga = 1000.*(Tdsx(e4,phi4,e5,phi5,theta,r45y) - Tusx(e2,phi2,e3,phi3,theta,r23y))/(zp4-zp2);
	if (DEBUG)
	{
		printf("\nPscalc: %f",ga);
	}

	*(double *)precord->vale = ga;

	return(0);
}
epicsRegisterFunction(calcInit);
epicsRegisterFunction(calcThetaRead);
epicsRegisterFunction(calcXRead);
epicsRegisterFunction(calcYRead);
epicsRegisterFunction(calcPsRead);
epicsRegisterFunction(calcGaRead);