#include <epicsStdlib.h>
#include <epicsStdioRedirect.h>
#include <epicsMath.h>
#include <dbAccess.h>
#include <dbEvent.h>
#include <dbDefs.h>
#include <recGbl.h>
#include <dbCommon.h>
#include <registryFunction.h>
#include <epicsExport.h>
#include <recSup.h>
#include <aSubRecord.h>
#include <pinfo.h>
#include <alarm.h>

#define DEBUG 0

double T(double x, double g, double z){
	double f = x + g/1000.*z;
	return f;
}
double alpha1yW(double y, double ps, double zp2, double zrel, double zp4, double th, double rp1x){
	double f = T(y,ps,zp2)*zrel + T(y,ps,zp4)*(1-zrel) + th/1000.*rp1x;
	if (DEBUG)
	{
		printf("\nalpha1y: %f",f);
	}
	return f;
}
double alpha23yW(double y, double ps, double zp2, double th, double r23x){
	double Tusy = T(y,ps,zp2);
	double al = Tusy+th/1000.*r23x;
	if (DEBUG)
	{
		printf("\nTusy: %f",Tusy);
		printf("\nalpha23y: %f",al);
	}
	return al;
}
double alpha23xW(double x, double ga, double zp2, double th, double r23y){
	double Tusx = T(x,ga,zp2);
	double al = Tusx-th/1000.*r23y;
	if (DEBUG)
	{
		printf("\nTusx: %f",Tusx);
		printf("\nalpha23x: %f",al);
	}
	return al;
}
double alpha45yW(double y, double ps, double zp4, double th, double r45x){
	double Tdsy = T(y,ps,zp4);
	double al = Tdsy+th/1000.*r45x;
	if (DEBUG)
	{
		printf("\nTusy: %f",Tdsy);
		printf("\nalpha45y: %f",al);
	}
	return al;
}
double alpha45xW(double x, double ga, double zp4, double th, double r45y){
	double Tdsx = T(x,ga,zp4);
	double al = Tdsx-th/1000.*r45y;
	if (DEBUG)
	{
		printf("\nTusx: %f",Tdsx);
		printf("\nalpha45x: %f",al);
	}
	return al;
}

double calcPhi1 (double y, double ps, double zp2, double zrel, double zp4, double th, double rp1x, double e1){
	double ph1 = asin(alpha1yW(y, ps, zp2, zrel, zp4, th, rp1x)/fabs(e1));
	if (DEBUG)
	{
		printf("\nPhi1: %f", ph1);
	}
	return ph1;
}
double calcPhi2 (double y, double ps, double zp2, double th, double r23x, double x, double ga, double r23y, double e2){
	double ph1 = asin((alpha23yW(y,ps,zp2,th,r23x) + alpha23xW(x,ga,zp2,th,r23y))/(sqrt(2)*fabs(e2)));
		if (DEBUG)
	{
		printf("\nPhi2: %f", ph1);
	}
	return ph1;
}
double calcPhi3 (double y, double ps, double zp2, double th, double r23x, double x, double ga, double r23y, double e3){
	double ph1 = asin((alpha23yW(y,ps,zp2,th,r23x) - alpha23xW(x,ga,zp2,th,r23y))/(sqrt(2)*fabs(e3)));
		if (DEBUG)
	{
		printf("\nPhi3: %f", ph1);
	}
	return ph1;
}
double calcPhi4 (double y, double ps, double zp4, double th, double r45x, double x, double ga, double r45y, double e4){
	double ph1 = asin((alpha45yW(y,ps,zp4,th,r45x) + alpha45xW(x,ga,zp4,th,r45y))/(sqrt(2)*fabs(e4)));
		if (DEBUG)
	{
		printf("\nPhi4: %f", ph1);
	}
	return ph1;
}
double calcPhi5 (double y, double ps, double zp4, double th, double r45x, double x, double ga, double r45y, double e5){
	double ph1 = asin((alpha45yW(y,ps,zp4,th,r45x) - alpha45xW(x,ga,zp4,th,r45y))/(sqrt(2)*fabs(e5)));
		if (DEBUG)
	{
		printf("\nPhi5: %f", ph1);
	}
	return ph1;
}

static int calcCM1(aSubRecord *precord){
	double e1 = *(double*)precord->a;
	double e2 = *(double*)precord->b;
	double e3 = *(double*)precord->c;
	double e4 = *(double*)precord->d;
	double e5 = *(double*)precord->e;
	double zp2 = *(double*)precord->f;
	double zp4 = *(double*)precord->g;
	double rp1x = *(double*)precord->h;
	double r23x = *(double*)precord->i;
	double r23y = *(double*)precord->j;
	double r45x = *(double*)precord->k;
	double r45y = *(double*)precord->l;
	double x = *(double*)precord->m;
	double y = *(double*)precord->n;
	double th = *(double*)precord->o;
	double ps = *(double*)precord->p;
	double ga = *(double*)precord->q;
	double zrel = *(double*)precord->r;

	double phi1 = calcPhi1(y,ps,zp2,zrel,zp4,th,rp1x,e1);
	double phi2 = calcPhi2(y,ps,zp2,th,r23x,x,ga,r23y,e2);
	double phi3 = calcPhi3(y,ps,zp2,th,r23x,x,ga,r23y,e3);
	double phi4 = calcPhi4(y,ps,zp4,th,r45x,x,ga,r45y,e4);
	double phi5 = calcPhi5(y,ps,zp4,th,r45x,x,ga,r45y,e5);

	if (isnan(phi1) || isnan(phi2) || isnan(phi3) || isnan(phi4) || isnan(phi5))
	{
		precord->brsv = MINOR_ALARM;
		return -1;
	}
	else{
		*(double*)precord->vala = phi1;
	}
	return 0;
}
static int calcCM2(aSubRecord *precord){
	double e1 = *(double*)precord->a;
	double e2 = *(double*)precord->b;
	double e3 = *(double*)precord->c;
	double e4 = *(double*)precord->d;
	double e5 = *(double*)precord->e;
	double zp2 = *(double*)precord->f;
	double zp4 = *(double*)precord->g;
	double rp1x = *(double*)precord->h;
	double r23x = *(double*)precord->i;
	double r23y = *(double*)precord->j;
	double r45x = *(double*)precord->k;
	double r45y = *(double*)precord->l;
	double x = *(double*)precord->m;
	double y = *(double*)precord->n;
	double th = *(double*)precord->o;
	double ps = *(double*)precord->p;
	double ga = *(double*)precord->q;
	double zrel = *(double*)precord->r;

	double phi1 = calcPhi1(y,ps,zp2,zrel,zp4,th,rp1x,e1);
	double phi2 = calcPhi2(y,ps,zp2,th,r23x,x,ga,r23y,e2);
	double phi3 = calcPhi3(y,ps,zp2,th,r23x,x,ga,r23y,e3);
	double phi4 = calcPhi4(y,ps,zp4,th,r45x,x,ga,r45y,e4);
	double phi5 = calcPhi5(y,ps,zp4,th,r45x,x,ga,r45y,e5);

	if (isnan(phi1) || isnan(phi2) || isnan(phi3) || isnan(phi4) || isnan(phi5))
	{
		precord->brsv = MINOR_ALARM;
		return -1;
	}
	else{
		*(double*)precord->valb = phi2;
	}
	return 0;
}
static int calcCM3(aSubRecord *precord){
	double e1 = *(double*)precord->a;
	double e2 = *(double*)precord->b;
	double e3 = *(double*)precord->c;
	double e4 = *(double*)precord->d;
	double e5 = *(double*)precord->e;
	double zp2 = *(double*)precord->f;
	double zp4 = *(double*)precord->g;
	double rp1x = *(double*)precord->h;
	double r23x = *(double*)precord->i;
	double r23y = *(double*)precord->j;
	double r45x = *(double*)precord->k;
	double r45y = *(double*)precord->l;
	double x = *(double*)precord->m;
	double y = *(double*)precord->n;
	double th = *(double*)precord->o;
	double ps = *(double*)precord->p;
	double ga = *(double*)precord->q;
	double zrel = *(double*)precord->r;

	double phi1 = calcPhi1(y,ps,zp2,zrel,zp4,th,rp1x,e1);
	double phi2 = calcPhi2(y,ps,zp2,th,r23x,x,ga,r23y,e2);
	double phi3 = calcPhi3(y,ps,zp2,th,r23x,x,ga,r23y,e3);
	double phi4 = calcPhi4(y,ps,zp4,th,r45x,x,ga,r45y,e4);
	double phi5 = calcPhi5(y,ps,zp4,th,r45x,x,ga,r45y,e5);

	if (isnan(phi1) || isnan(phi2) || isnan(phi3) || isnan(phi4) || isnan(phi5))
	{
		precord->brsv = MINOR_ALARM;
		return -1;
	}
	else{
		*(double*)precord->valc = phi3;
	}
	return 0;
}
static int calcCM4(aSubRecord *precord){
	double e1 = *(double*)precord->a;
	double e2 = *(double*)precord->b;
	double e3 = *(double*)precord->c;
	double e4 = *(double*)precord->d;
	double e5 = *(double*)precord->e;
	double zp2 = *(double*)precord->f;
	double zp4 = *(double*)precord->g;
	double rp1x = *(double*)precord->h;
	double r23x = *(double*)precord->i;
	double r23y = *(double*)precord->j;
	double r45x = *(double*)precord->k;
	double r45y = *(double*)precord->l;
	double x = *(double*)precord->m;
	double y = *(double*)precord->n;
	double th = *(double*)precord->o;
	double ps = *(double*)precord->p;
	double ga = *(double*)precord->q;
	double zrel = *(double*)precord->r;

	double phi1 = calcPhi1(y,ps,zp2,zrel,zp4,th,rp1x,e1);
	double phi2 = calcPhi2(y,ps,zp2,th,r23x,x,ga,r23y,e2);
	double phi3 = calcPhi3(y,ps,zp2,th,r23x,x,ga,r23y,e3);
	double phi4 = calcPhi4(y,ps,zp4,th,r45x,x,ga,r45y,e4);
	double phi5 = calcPhi5(y,ps,zp4,th,r45x,x,ga,r45y,e5);

	if (isnan(phi1) || isnan(phi2) || isnan(phi3) || isnan(phi4) || isnan(phi5))
	{
		precord->brsv = MINOR_ALARM;
		return -1;
	}
	else{
		*(double*)precord->vald = phi4;
	}
	return 0;
}
static int calcCM5(aSubRecord *precord){
	double e1 = *(double*)precord->a;
	double e2 = *(double*)precord->b;
	double e3 = *(double*)precord->c;
	double e4 = *(double*)precord->d;
	double e5 = *(double*)precord->e;
	double zp2 = *(double*)precord->f;
	double zp4 = *(double*)precord->g;
	double rp1x = *(double*)precord->h;
	double r23x = *(double*)precord->i;
	double r23y = *(double*)precord->j;
	double r45x = *(double*)precord->k;
	double r45y = *(double*)precord->l;
	double x = *(double*)precord->m;
	double y = *(double*)precord->n;
	double th = *(double*)precord->o;
	double ps = *(double*)precord->p;
	double ga = *(double*)precord->q;
	double zrel = *(double*)precord->r;

	double phi1 = calcPhi1(y,ps,zp2,zrel,zp4,th,rp1x,e1);
	double phi2 = calcPhi2(y,ps,zp2,th,r23x,x,ga,r23y,e2);
	double phi3 = calcPhi3(y,ps,zp2,th,r23x,x,ga,r23y,e3);
	double phi4 = calcPhi4(y,ps,zp4,th,r45x,x,ga,r45y,e4);
	double phi5 = calcPhi5(y,ps,zp4,th,r45x,x,ga,r45y,e5);

	if (isnan(phi1) || isnan(phi2) || isnan(phi3) || isnan(phi4) || isnan(phi5))
	{
		precord->brsv = MINOR_ALARM;
		return -1;
	}
	else{
		*(double*)precord->vale = phi5;
	}
	return 0;
}
epicsRegisterFunction(calcCM1);
epicsRegisterFunction(calcCM2);
epicsRegisterFunction(calcCM3);
epicsRegisterFunction(calcCM4);
epicsRegisterFunction(calcCM5);