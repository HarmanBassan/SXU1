/*
======================================================================
 
  Abs:  Header File for Magnet Subroutine Records
  
  Name: mgntSub.h

  Rem:  Magnet subroutine parameter definitions file.

  Side: see source file mgntSub.c

  Auth: dd-mmm-yyyy, Stephanie Allison   (SAA)
  Rev:  dd-mmm-yyyy, Reviewer's Name     (USERNAME)
----------------------------------------------------------------------
  Mod:
        20-Jan-2008, Kristi Luchini      (LUCHINI)
           add structure mgntWfCoef
        14-Jan-2007, Kristi Luchini      (LUCHINI)
           added HSTA_XXX_SHFT definitions.
           moved parameter definitions from mgntSub.c
           to header file.

======================================================================
*/
#ifndef MGNTSUB_H
#define MGNTSUB_H

/* Status Returns */
#define SUCCESS  0
#define ERROR   -1

/* Local definitions */
#define MGNT_MAX_POLY_COEF    12      /* Max # of polynomial coefficients    */
#define MGNT_CHICKEN_FACTOR   0.5     /* Factor used in reverse polynomial   */
#define MGNT_MIN_SLOPE        1E-30   /* Min slope in reverse polynomial     */

/* Reverse Polynomial Statuses */
#define MGNT_CONVERGED        0 
#define MGNT_ALMOST_CONVERGED 1 
#define MGNT_NO_CONVERGENCE   2 
#define MGNT_ZERO_SLOPE       3 
#define MGNT_POLY_ERROR       4 
#define LINEAR_COEF_NUM 2

#endif /* MGNTSUB_H  */
