/* EnsembleTrajectoryScan.h
 * 
 * This file is included in EnsembleTrajectoryScan.st.
 */


/* State codes for Build, Read and Execute. Careful, these must match the
 * corresponding MBBI records, but there is no way to check this */
#define BUILD_STATE_DONE            0
#define BUILD_STATE_BUSY            1
#define READ_STATE_DONE             0
#define READ_STATE_BUSY             1
#define EXECUTE_STATE_DONE          0
#define EXECUTE_STATE_MOVE_START    1
#define EXECUTE_STATE_EXECUTING     2
#define EXECUTE_STATE_FLYBACK       3

/* Status codes for Build, Execute and Read */
#define STATUS_UNDEFINED 0
#define STATUS_SUCCESS   1
#define STATUS_FAILURE   2
#define STATUS_ABORT     3
#define STATUS_TIMEOUT   4
#define STATUS_WARNING   5

/* Time modes */
#define TIME_MODE_TOTAL         0
#define TIME_MODE_PER_ELEMENT   1

/* Move modes */
#define MOVE_MODE_RELATIVE   0
#define MOVE_MODE_ABSOLUTE   1
#define MOVE_MODE_HYBRID     2

/* The maximum number of axes per controller.  If this is changed from 8
 * then many assign statements in this file must be changed */
#define MAX_AXES 8

#define MSGSIZE 40

/* Define PVs */
int     debugLevel;  assign debugLevel   to "{DEV}:DebugLevel.VAL"; 
monitor debugLevel;
int     execState;   assign execState    to "{DEV}:ExecState.VAL";  
monitor execState; 
int     execStatus;  assign execStatus   to "{DEV}:ExecStatus.VAL";   
string  execMessage; assign execMessage  to "{DEV}:ExecMessage.VAL";
int     abort;       assign abort        to "{DEV}:Abort.VAL";   
monitor abort;
int     simMode;     assign simMode      to "{DEV}:SimMode.VAL";   
monitor simMode;
/*** BEGIN: Specific to EnsembleTrajectoryScan.st ***/

/* time since trajectory start */
double  elapsedTime; assign elapsedTime  to "{DEV}:ElapsedTime.VAL";      


/* EPICS motor record resolution */
double  epicsMotorMres[MAX_AXES]; 
assign  epicsMotorMres to {"","","","","","","",""};
monitor epicsMotorMres;

/* EPICS motor-controller card number.  (For now, we talk to the controller via drvMAX.cc) */
int  epicsMotorCard[MAX_AXES]; 
assign  epicsMotorCard to {"","","","","","","",""};
monitor epicsMotorCard;

/* EPICS motor record soft limits */
double  epicsMotorHLM[MAX_AXES]; 
assign  epicsMotorHLM to {"","","","","","","",""};
monitor epicsMotorHLM;
double  epicsMotorLLM[MAX_AXES]; 
assign  epicsMotorLLM to {"","","","","","","",""};
monitor epicsMotorLLM;
double epicsMotorReadbacks[MAX_AXES];
assign epicsMotorReadbacks to  {"","","","","","","",""};
monitor epicsMotorReadbacks;

/* We don't assign the EPICS motors here because there may be fewer than 
 * MAX_AXES actually in use. */
double  epicsMotorPos[MAX_AXES]; 
assign  epicsMotorPos to {"","","","","","","",""};
monitor epicsMotorPos;

int  epicsMotorDir[MAX_AXES]; 
assign  epicsMotorDir to {"","","","","","","",""};
monitor epicsMotorDir;

double  epicsMotorOff[MAX_AXES]; 
assign  epicsMotorOff to {"","","","","","","",""};
monitor epicsMotorOff;

double  epicsMotorDone[MAX_AXES]; 
assign  epicsMotorDone to {"","","","","","","",""};
monitor epicsMotorDone;

double  epicsMotorVELO[MAX_AXES]; 
assign  epicsMotorVELO to {"","","","","","","",""};
monitor epicsMotorVELO;

double  epicsMotorVMAX[MAX_AXES]; 
assign  epicsMotorVMAX to {"","","","","","","",""};
monitor epicsMotorVMAX;

double  epicsMotorVMIN[MAX_AXES]; 
assign  epicsMotorVMIN to {"","","","","","","",""};
monitor epicsMotorVMIN;

double  epicsMotorACCL[MAX_AXES]; 
assign  epicsMotorACCL to {"","","","","","","",""};
monitor epicsMotorACCL;


evflag execStateMon;    sync execState  execStateMon;
evflag abortMon;        sync abort      abortMon;

/* This is going to get messy.  We need to use Ensemble commands like "VELOCITY" and "PVT",
 * But they aren't available via the ASCII interface we're using to send commands.  So we
 * use ASCII-legal commands to tell an Aerobasic program the commands we want to execute,
 * and have the AeroBasic program execute those commands.
 */

/* defines for IGLOBAL values to tell AeroBasic program which command to invoke */
#define cmdDONE					0
#define cmdVELOCITY_ON			1
#define cmdVELOCITY_OFF			2
#define cmdHALT					3
#define cmdSTART				4
#define cmdPVT_INIT_TIME_ABS	5
#define cmdPVT_INIT_TIME_INC	6
#define cmdPVT1					7	/* PVT command for one motor (PVT i1 d1, d2, TIME d3) */
#define cmdPVT2					8	/* PVT command for two motors (PVT i1 d1, d2 i2 d3, d4 TIME d5)*/
#define cmdPVT3					9
#define cmdPVT4					10
#define cmdABORT				11
#define cmdSTARTABORT			12
#define cmdSCOPEBUFFER			13
#define cmdSCOPEDATA			14
#define cmdSCOPESTATUS			15
#define cmdSCOPETRIG			16	/* if IGLOBAL(iarg1Var)==1, stop scope */
#define cmdSCOPETRIGPERIOD		17
#define cmdDRIVEINFO			18	/* per Aerotech email, but not found in 4.02.004 doc */
#define cmdLINEAR				19	/* LINEAR @IGLOBAL(iarg1Var) DGLOBAL(darg1Var) FDGLOBAL(darg1Var) */
#define cmdDATAACQ_TRIG			20	/* DATAACQ @IGLOBAL(iarg1Var) TRIGGER IGLOBAL(1arg2Var) */
#define cmdDATAACQ_INP			21	/* DATAACQ @IGLOBAL(iarg1Var) INPUT IGLOBAL(1arg2Var) */
#define cmdDATAACQ_ON			22	/* DATAACQ @IGLOBAL(iarg1Var) ON IGLOBAL(1arg2Var) */
#define cmdDATAACQ_OFF			23	/* DATAACQ @IGLOBAL(iarg1Var) OFF */
#define cmdDATAACQ_READ			24	/* DATAACQ @IGLOBAL(iarg1Var) READ IGLOBAL(1arg2Var), IGLOBAL(1arg3Var) */
#define cmdDOTRAJECTORY			25	/* for motor IGLOBAL(iarg1Var); 3*IGLOBAL(iarg2Var) DGLOBALs (PVT) have been loaded */

#define cmdVar		45
#define iarg1Var	46
#define iarg2Var	47
#define iarg3Var	48
#define iarg4Var	49
#define darg1Var	1
#define darg2Var	2
#define darg3Var	3
#define numIArg		44
#define numDArg		43
#define pvtWaitMSVar	42

/* Numerical values for first arg for cmdSCOPEDATA */
#define sd_PositionCommand	0
#define sd_PositionFeedback	1
#define sd_ExternalPosition	2
#define sd_AxisFault		3
#define sd_AxisStatus		4
#define sd_AnalogInput0		5
#define sd_AnalogInput1		6
#define sd_AnalogOutput0	7
#define sd_AnalogOutput1	8
#define sd_DigitalInput0	9
#define sd_DigitalInput1	10
#define sd_DigitalOutput0	11
#define sd_DigitalOutput1	12
#define sd_CurrentCommand	13
#define sd_CurrentFeedback	14
#define sd_OptionalData1	15
#define sd_OptionalData2	16
#define sd_ProgramCounter	17

