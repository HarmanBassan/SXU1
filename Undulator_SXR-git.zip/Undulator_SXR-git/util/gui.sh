#!/bin/bash
source $EPICS_SETUP/go_epics_3-14-12.bash 
cd $APP/UndulatorMotionControls/current/util
#cd /u/cd/zoven/workspace/APP/LCLSII/UndulatorMotionControls/mergeBetweenSLACandLBNL/merged_version/util
edm -x -eolc -m "P=USEG:MMF:1:" main_screen.edl &
