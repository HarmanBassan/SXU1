#!/bin/bash

cd /afs/slac.stanford.edu/u/cd/zoven/workspace/iocs/LCLSII/UndulatorMotionControls/MAIN_TRUNK/util/ 

edm -x -eolc -m 'P=AERO:B034_196:0:,M_T=TOP:MOTR,M_B=BOT:MOTR' LCLS_II_UNDMC_ts_gantry.edl &

