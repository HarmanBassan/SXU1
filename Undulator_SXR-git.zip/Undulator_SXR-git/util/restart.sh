#!/bin/bash

# Exit iocConsole with clean-up option
iocConsole sioc-b81-mc01 -c;

# Wait for 5 seconds
sleep 5;

# Start iocConsole with stay-up option
iocConsole sioc-b81-mc01 -s

