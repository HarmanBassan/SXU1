#!/bin/bash
source $EPICS_SETUP/go_epics_3-14-12.bash 
cd $APP/Undulator_SXR/current/util
edm -x -eolc -m "P=USEG:MMF:1:" main_screen.edl &
