#!/bin/bash

cd /afs/slac.stanford.edu/u/cd/zoven/workspace/testIOCs/LCLSII/UndulatorMotionControls/MAIN_TRUNK/util/ 

edm -x -eolc -m 'P=USEG:LBNL_MMF:1:,M_T=TOP:MOTR,M_B=BOT:MOTR' LCLS_II_UNDMC_ts_gantry.edl &

