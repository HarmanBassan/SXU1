#!/bin/bash

cd /afs/slac.stanford.edu/u/cd/zoven/workspace/testIOCs/LCLSII/UndulatorMotionControls/MAIN_TRUNK/util/ 

edm -x -eolc -m 'P=USEG:LBNL_MMF:1:,M_LT=LT:MOTR,M_RT=RT:MOTR,M_LB=LB:MOTR,M_RB=RB:MOTR,M_VT=TOP:VRT_MTR,M_VB=BOTTOM:VRT_MTR' LCLS_II_UNDMC_test_stand.edl &

